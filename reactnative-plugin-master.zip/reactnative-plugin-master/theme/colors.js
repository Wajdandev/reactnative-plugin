export default {
  white: '#fff',
  black: '#000',
  light: '#f8f4f4',
  danger: '#ff5252',
  lightGrey: '#DCDCDC',
  darkGrey: '#A9A9A9',
  inActive: '#808080',
};
